CREATE EXTENSION IF NOT EXISTS postgis;

CREATE TABLE IF NOT EXISTS rooms (
  room_id   SERIAL PRIMARY KEY,
  geometry  geometry(Polygon, 4326) NOT NULL,
  name      text NOT NULL,
  usage     text NULL,
  notes     text NULL
);

-- Seed a single simple square polygon if empty
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM rooms) THEN
    -- A more realistic single-floor layout: 2 rows of rooms with a corridor.
    -- Coordinates are still SRID 4326; for PoC visuals we treat them as planar.
    INSERT INTO rooms (geometry, name, usage, notes)
    VALUES
      -- South row
      (ST_GeomFromText('POLYGON((-122.401000 37.792000,-122.401000 37.792130,-122.400850 37.792130,-122.400850 37.792000,-122.401000 37.792000))', 4326), 'Office 101', 'Office', NULL),
      (ST_GeomFromText('POLYGON((-122.400850 37.792000,-122.400850 37.792130,-122.400700 37.792130,-122.400700 37.792000,-122.400850 37.792000))', 4326), 'Office 102', 'Office', NULL),
      (ST_GeomFromText('POLYGON((-122.400700 37.792000,-122.400700 37.792130,-122.400550 37.792130,-122.400550 37.792000,-122.400700 37.792000))', 4326), 'Conference 103', 'Conference', NULL),
      (ST_GeomFromText('POLYGON((-122.400550 37.792000,-122.400550 37.792130,-122.400400 37.792130,-122.400400 37.792000,-122.400550 37.792000))', 4326), 'Storage 104', 'Storage', NULL),

      -- Corridor
      (ST_GeomFromText('POLYGON((-122.401000 37.792130,-122.401000 37.792170,-122.400400 37.792170,-122.400400 37.792130,-122.401000 37.792130))', 4326), 'Corridor', 'Circulation', NULL),

      -- North row
      (ST_GeomFromText('POLYGON((-122.401000 37.792170,-122.401000 37.792300,-122.400850 37.792300,-122.400850 37.792170,-122.401000 37.792170))', 4326), 'Office 201', 'Office', NULL),
      (ST_GeomFromText('POLYGON((-122.400850 37.792170,-122.400850 37.792300,-122.400700 37.792300,-122.400700 37.792170,-122.400850 37.792170))', 4326), 'Office 202', 'Office', NULL),
      (ST_GeomFromText('POLYGON((-122.400700 37.792170,-122.400700 37.792300,-122.400550 37.792300,-122.400550 37.792170,-122.400700 37.792170))', 4326), 'Breakroom 203', 'Breakroom', NULL),
      (ST_GeomFromText('POLYGON((-122.400550 37.792170,-122.400550 37.792300,-122.400400 37.792300,-122.400400 37.792170,-122.400550 37.792170))', 4326), 'Restroom 204', 'Restroom', NULL);
  END IF;
END $$;
